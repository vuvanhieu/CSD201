import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

class BSTree {
    Node root;

    BSTree() {
        root = null;
    }
    
    // Method to generate a DOT file representing the tree
    void toDotFile(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write("digraph BST {\n");
            writer.write("  node [shape=record];\n");
            toDotFileRec(writer, root);
            writer.write("}\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private void toDotFileRec(BufferedWriter writer, Node node) throws IOException {
        if (node != null) {
            writer.write("  node" + node.info + " [label=\"" + node.info + "\"];\n");
            if (node.left != null) {
                writer.write("  node" + node.info + " -> node" + node.left.info + " [label=\"L\"];\n");
                toDotFileRec(writer, node.left);
            }
            if (node.right != null) {
                writer.write("  node" + node.info + " -> node" + node.right.info + " [label=\"R\"];\n");
                toDotFileRec(writer, node.right);
            }
        }
    }
    
    // Insertion
    void insert(int x) {
        root = insertRec(root, x);
    }

    Node insertRec(Node root, int x) {
        if (root == null) {
            root = new Node(x);
            return root;
        }

        if (x < root.info) {
            root.left = insertRec(root.left, x);
        } else if (x > root.info) {
            root.right = insertRec(root.right, x);
        }

        return root;
    }

    // In-order traversal
    void inOrder(Node p) {
        if (p != null) {
            inOrder(p.left);
            visit(p);
            inOrder(p.right);
        }
    }

    // Pre-order traversal
    void preOrder(Node p) {
        if (p != null) {
            visit(p);
            preOrder(p.left);
            preOrder(p.right);
        }
    }

    // Post-order traversal
    void postOrder(Node p) {
        if (p != null) {
            postOrder(p.left);
            postOrder(p.right);
            visit(p);
        }
    }

    // Search for a node with key x
    Node search(int x) {
        return searchRec(root, x);
    }

    Node searchRec(Node root, int x) {
        if (root == null || root.info == x) {
            return root;
        }

        if (x < root.info) {
            return searchRec(root.left, x);
        }

        return searchRec(root.right, x);
    }

    // Delete a node by merging
    void deleteByMerging(int x) {
        root = deleteRecMerge(root, x);
    }

    Node deleteRecMerge(Node root, int x) {
        if (root == null) {
            return root;
        }

        if (x < root.info) {
            root.left = deleteRecMerge(root.left, x);
        } else if (x > root.info) {
            root.right = deleteRecMerge(root.right, x);
        } else {
            // Node with one child or no child
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }

            // Node with two children: Find the maximum value node in the left subtree
            root.info = maxValue(root.left);

            // Delete the maximum value node from the left subtree
            root.left = deleteRecMerge(root.left, root.info);
        }
        return root;
    }

    int maxValue(Node root) {
        int maxValue = root.info;
        while (root.right != null) {
            maxValue = root.right.info;
            root = root.right;
        }
        return maxValue;
    }

    // Delete a node by copying
    void deleteByCopying(int x) {
        root = deleteRecCopy(root, x);
    }

    Node deleteRecCopy(Node root, int x) {
        if (root == null) {
            return root;
        }

        if (x < root.info) {
            root.left = deleteRecCopy(root.left, x);
        } else if (x > root.info) {
            root.right = deleteRecCopy(root.right, x);
        } else {
            // Node with one child or no child
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }

            // Node with two children: Find the minimum value node in the right subtree
            root.info = minValue(root.right);

            // Delete the minimum value node from the right subtree
            root.right = deleteRecCopy(root.right, root.info);
        }
        return root;
    }

    int minValue(Node root) {
        int minValue = root.info;
        while (root.left != null) {
            minValue = root.left.info;
            root = root.left;
        }
        return minValue;
    }

    void visit(Node p) {
        System.out.print(p.info + " ");
    }
}
