import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.*;
import java.util.*;

public class Main {
    // Method to convert DOT file to PNG using Graphviz
    private static void generatePngFromDot(String dotFile, String pngFile) {
        try {
            Process process = Runtime.getRuntime().exec("dot -Tpng " + dotFile + " -o " + pngFile);
            process.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
    
    public static void main(String[] args) {
        BSTree tree = new BSTree();

        // Insert elements into the tree
//         5  10  2   6   4   7   3   6  105
        tree.insert(5);
        tree.insert(10);
        tree.insert(2);
        tree.insert(6);
        tree.insert(4);
        tree.insert(7);
        tree.insert(3);
        tree.insert(6);
        tree.insert(105);
        
        
        // Generate a graphical representation of the tree
        String dotFile = "bstree.dot";
        tree.toDotFile(dotFile);

        // Convert the DOT file to an image (PNG)
        String pngFile = "bstree.png";
        generatePngFromDot(dotFile, pngFile);

//        System.out.println("In-order traversal:");
//        tree.inOrder(tree.root);
//        System.out.println("\nGenerated a graphical representation of the tree in " + pngFile);
//        
//        // In-order traversal
//        System.out.println("In-order traversal:");
//        tree.inOrder(tree.root);
//
//        // Pre-order traversal
//        System.out.println("\nPre-order traversal:");
//        tree.preOrder(tree.root);
//
//        // Post-order traversal
//        System.out.println("\nPost-order traversal:");
//        tree.postOrder(tree.root);

        // Search for an element
        int searchKey = 100;
        Node searchResult = tree.search(searchKey);
        if (searchResult != null) {
            System.out.println("\nFound " + searchKey + " in the tree.");
        } else {
            System.out.println("\n" + searchKey + " not found in the tree.");
        }
//
//        // Delete an element by merging
//        int deleteKeyMerging = 30;
//        System.out.println("\nDeleting " + deleteKeyMerging + " by merging:");
//        tree.deleteByMerging(deleteKeyMerging);
//        tree.inOrder(tree.root);
//
//        // Delete an element by copying
//        int deleteKeyCopying = 50;
//        System.out.println("\nDeleting " + deleteKeyCopying + " by copying:");
//        tree.deleteByCopying(deleteKeyCopying);
//        tree.inOrder(tree.root);
        int choice;
        Scanner sca = new Scanner(System.in);
        System.out.println();
        System.out.println(" 1. In-order traversal");
        System.out.println(" 2. In-order traversal");
        System.out.println(" 3. Post-order traversal");
        System.out.print("    Your selection (1 -> 3): ");
        choice = sca.nextInt();
        sca.nextLine();
        switch(choice) {
           case 1: 
                // In-order traversal
                System.out.println("In-order traversal:");
                tree.inOrder(tree.root);
                break;
           case 2: 
                // In-order traversal
                System.out.println("In-order traversal:");
                tree.inOrder(tree.root);
                break;
           case 3: 
                 // Post-order traversal
                 System.out.println("\nPost-order traversal:");
                 tree.postOrder(tree.root);
                 break;
           default: System.out.println("Wrong selection");
          }
         System.out.println();
    }
}
