
import java.io.IOException;
import java.util.Scanner;

public class Main {

    private static void generatePngFromDot(String dotFile, String pngFile) {
        try {
            Process process = Runtime.getRuntime().exec("dot -Tpng " + dotFile + " -o " + pngFile);
            process.waitFor();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String args[]) throws Exception {
        AVLTree tree = new AVLTree();
//        boolean exit = false; // Flag to control loop

//        while (!exit) { // Loop until the user chooses to exit
        int choice;
        Scanner sca = new Scanner(System.in);
        System.out.println();
        System.out.println(" 1. Test f1 (1 mark)");
        System.out.println(" 2. Test f2 (1 mark)");
        System.out.println(" 3. Test f3 (1 mark)");
        System.out.println(" 4. Test f4 (1 mark)");
        System.out.println(" 5. Delete by Merging");
        System.out.println(" 6. Delete by Copying");
        System.out.println(" 7. Search by xPrice");
        System.out.println(" 8. Exit");
        System.out.print("    Your selection (1 -> 8): ");
        choice = sca.nextInt();
        sca.nextLine();

        switch (choice) {
            case 1:
                tree.f1();
                System.out.println("Your output:");
                Lib.viewFile("f1.txt");

                // Generate a graphical representation of the tree for f1
                String f1DotFile = "avl_tree_f1.dot";
                tree.toDotFile(f1DotFile);
                generatePngFromDot(f1DotFile, "avl_tree_f1.png");
                break;
            case 2:
                tree.f2();
                System.out.println("Your output:");
                Lib.viewFile("f2.txt");

                // Generate a graphical representation of the tree for f2
                String f2DotFile = "avl_tree_f2.dot";
                tree.toDotFile(f2DotFile);
                generatePngFromDot(f2DotFile, "avl_tree_f2.png");
                break;
            case 3:
                tree.f3();
                System.out.println("Your output:");
                Lib.viewFile("f3.txt");

                // Generate a graphical representation of the updated tree
                String updatedDotFile = "avl_tree_f3.dot";
                tree.toDotFile(updatedDotFile);
                generatePngFromDot(updatedDotFile, "avl_tree_f3.png");
                System.out.println(" AVLTree:");
                break;
            case 4:
                tree.f4();
                System.out.println("Your output:");
                Lib.viewFile("f4.txt");

                // Generate a graphical representation of the tree for f4
                String f4DotFile = "avl_tree_f4.dot";
                tree.toDotFile(f4DotFile);
                generatePngFromDot(f4DotFile, "avl_tree_f4.png");
                break;
            case 5:
                // Delete by Merging
                System.out.print("Enter the price of the node to delete: ");
                int priceToDelete = sca.nextInt();
                tree.deleteByMerging(priceToDelete);
                System.out.println("Node with price " + priceToDelete + " deleted.");

                // Generate a graphical representation of the updated tree
                updatedDotFile = "avl_tree_delete_merging.dot";
                tree.toDotFile(updatedDotFile);
                generatePngFromDot(updatedDotFile, "avl_tree_delete_merging.png");
                System.out.println("AVLTree delete:");
                break;

            case 6:
                // Delete by Copying
                System.out.print("Enter the price of the node to delete by copying: ");
                int priceToDeleteCopy = sca.nextInt();
                tree.deleteByCopying(priceToDeleteCopy);
                System.out.println("Node with price " + priceToDeleteCopy + " deleted by copying.");

                // Generate a graphical representation of the updated tree
                String updatedDotFileCopy = "avl_tree_delete_copying.dot";
                tree.toDotFile(updatedDotFileCopy);
                generatePngFromDot(updatedDotFileCopy, "avl_tree_delete_copying.png");
                System.out.println("Updated AVLTree (deleted by copying):");
                break;
            case 7:
                // Search
                System.out.print("Enter the price to search for: ");
                int priceToSearch = sca.nextInt();
                Node foundNode = tree.search(priceToSearch);
                if (foundNode != null) {
                    System.out.println("Node with price " + priceToSearch + " found: Owner = " + foundNode.info.owner);
                } else {
                    System.out.println("Node with price " + priceToSearch + " not found.");
                }
                break;

//            case 8:
//                exit = true; // Set the exit flag to true to exit the loop
//                break;
            default:
                System.out.println("Wrong selection");
        }
    }
//        System.out.println("Exiting the program.");
//    }
}
