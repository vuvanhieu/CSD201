class Node {
    Car info;
    Node left, right;
    int height; // Height of the node
    int bal;    // Balance factor of the node

    Node(Car x) {
        info = x;
        left = right = null;
        height = 1;
        bal = 0;
    }
}
