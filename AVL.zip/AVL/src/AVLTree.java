/* This program contains 2 parts: (1) and (2)
   YOUR TASK IS TO COMPLETE THE PART  (2)  ONLY
 */
//(1)==============================================================
import java.io.*;
import java.util.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

class AVLTree
  {Node root;
   AVLTree() {root=null;}
   
   // Method to generate a DOT file representing the tree
    void toDotFile(String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            writer.write("digraph BST {\n");
            writer.write("  node [shape=record];\n");
            toDotFileRec(writer, root);
            writer.write("}\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
   
    private void toDotFileRec(BufferedWriter writer, Node node) throws IOException {
     if (node != null) {
         // Use different colors for nodes based on balance and level
         String fillColor = "white"; // Default color
         if (node.bal < -1) {
             fillColor = "red"; // Red for left-heavy nodes
         } else if (node.bal > 1) {
             fillColor = "green"; // Green for right-heavy nodes
         }

         // Add level information to node label
         String nodeLabel = "Owner: " + node.info.owner + " \nPrice: " + node.info.price ; //"\nLevel: " + node.level;

         writer.write("  node" + node.info.owner + " [label=\"" + nodeLabel + "\", style=filled, fillcolor=" + fillColor + "];\n");

         if (node.left != null) {
             writer.write("  node" + node.info.owner + " -> node" + node.left.info.owner + " [label=\"L\"];\n");
             toDotFileRec(writer, node.left);
         }
         if (node.right != null) {
             writer.write("  node" + node.info.owner + " -> node" + node.right.info.owner + " [label=\"R\"];\n");
             toDotFileRec(writer, node.right);
         }
     }
 }

   
   boolean isEmpty()
      {return(root==null);
      }
   
   void clear()
      {root=null;
      }
   
   void fvisit(Node p, RandomAccessFile f) throws Exception
     {if(p != null) f.writeBytes(p.info + " ");
     }
   
   void preOrder(Node p, RandomAccessFile f) throws Exception
     {if(p==null) return;
      fvisit(p,f);
      preOrder(p.left,f);
      preOrder(p.right,f);
     }
   
   // Modified preOrder method to only display nodes within the [3, 5] price interval
    void preOrder2(Node p, RandomAccessFile f) throws Exception {
        if (p == null) return;
        if (p.info.price >= 3 && p.info.price <= 5) {
            fvisit(p, f);
        }
        preOrder2(p.left, f);
        preOrder2(p.right, f);
    }

   void inOrder(Node p, RandomAccessFile f) throws Exception
     {if(p==null) return;
      inOrder(p.left,f);
      fvisit(p,f);
      inOrder(p.right,f);
     }
   
   void postOrder(Node p, RandomAccessFile f) throws Exception
     {if(p==null) return;
      postOrder(p.left,f);
      postOrder(p.right,f);
      fvisit(p,f);
     }
  void breadth(Node p, RandomAccessFile f) throws Exception
    {if(p==null) return;
     Queue q = new Queue();
     q.enqueue(p);Node r;
     while(!q.isEmpty())
       {r = q.dequeue();
        fvisit(r,f);
        if(r.left!=null) q.enqueue(r.left);
        if(r.right!=null) q.enqueue(r.right);
       }
    }
  
   void loadData(int k)  //do not edit this function
     {String [] a = Lib.readLineToStrArray("data.txt", k);
      int [] b = Lib.readLineToIntArray("data.txt", k+1);
      int n = a.length;
      for(int i=0;i<n;i++) insert(a[i],b[i]);
     }

//===========================================================================
void insert(String xOwner, int xPrice) {
    if (xOwner.charAt(0) == 'B' || xPrice > 100) {
        System.out.println("Car not inserted due to condition.");
        return; // Do nothing if the condition is met
    }

    root = insertRec(root, xOwner, xPrice);
    // Balance the tree
    balanceTree(root);
}

private Node insertRec(Node root, String xOwner, int xPrice) {
    if (root == null) {
        return new Node(new Car(xOwner, xPrice));
    }

    if (xPrice < root.info.price) {
        root.left = insertRec(root.left, xOwner, xPrice);
    } else if (xPrice >= root.info.price) {
        root.right = insertRec(root.right, xOwner, xPrice);
    }

    // Update the height and balance factor
    root.height = 1 + Math.max(getHeight(root.left), getHeight(root.right));
    root.bal = getBalance(root);

    return root;
}

// Get the height of a node
private int getHeight(Node node) {
    if (node == null) {
        return 0;
    }
    return node.height;
}

// Get the balance factor of a node
private int getBalance(Node node) {
    if (node == null) {
        return 0;
    }
    return getHeight(node.left) - getHeight(node.right);
}

// Balance the tree using appropriate rotations
private Node balanceTree(Node node) {
    int balance = getBalance(node);

    // Left Heavy
    if (balance > 1) {
        // Left-Right Case
        if (getBalance(node.left) < 0) {
            node.left = rotateLeft(node.left);
        }
        // Left-Left Case
        return rotateRight(node);
    }
    // Right Heavy
    else if (balance < -1) {
        // Right-Left Case
        if (getBalance(node.right) > 0) {
            node.right = rotateRight(node.right);
        }
        // Right-Right Case
        return rotateLeft(node);
    }

    // Update height and balance factor
    node.height = 1 + Math.max(getHeight(node.left), getHeight(node.right));

    node.bal = getBalance(node);

    return node;
}


// Perform a left rotation
private Node rotateLeft(Node y) {
    Node x = y.right;
    Node T2 = x.left;

    // Perform rotation
    x.left = y;
    y.right = T2;

    // Update heights
    y.height = 1 + Math.max(getHeight(y.left), getHeight(y.right));
    x.height = 1 + Math.max(getHeight(x.left), getHeight(x.right));

    return x;
}

// Perform a right rotation
private Node rotateRight(Node x) {
    Node y = x.left;
    Node T2 = y.right;

    // Perform rotation
    y.right = x;
    x.left = T2;

    // Update heights
    x.height = 1 + Math.max(getHeight(x.left), getHeight(x.right));
    y.height = 1 + Math.max(getHeight(y.left), getHeight(y.right));

    return y;
}

  

  void f1() throws Exception
    {/* You do not need to edit this function. Your task is to complete insert  function
        above only.
     */
     clear();
     loadData(1);
     String fname = "f1.txt";
     File g123 = new File(fname);
     if(g123.exists()) g123.delete();
     RandomAccessFile  f = new RandomAccessFile(fname, "rw"); 
     preOrder(root,f);
     f.writeBytes("\r\n");
     inOrder(root,f);
     f.writeBytes("\r\n");
     f.close();
    }  
  
//=============================================================
  void f2() throws Exception
    {clear();
     loadData(4);
     String fname = "f2.txt";
     File g123 = new File(fname);
     if(g123.exists()) g123.delete();
     RandomAccessFile  f = new RandomAccessFile(fname, "rw"); 
     preOrder(root,f);
     f.writeBytes("\r\n");
    //------------------------------------------------------------------------------------
     /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/

    // Perform modified pre-order traversal
    preOrder2(root, f);

    //------------------------------------------------------------------------------------
     f.writeBytes("\r\n");
     f.close();
    }  


// f.writeBytes(" k = " + k + "\r\n");
//=============================================================
  void f3() throws Exception
    {clear();
     loadData(7);
     String fname = "f3.txt";
     File g123 = new File(fname);
     if(g123.exists()) g123.delete();
     RandomAccessFile  f = new RandomAccessFile(fname, "rw"); 
     breadth(root,f);
     f.writeBytes("\r\n");
    //------------------------------------------------------------------------------------
     /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/
     
    // Find and delete the first node with both children and price < 7
    Node parent = null;
    Node nodeToDelete = null;
    Node p = root;
    Queue q = new Queue();
    
    while (p != null) {
        if (p.left != null && p.right != null && p.info.price < 7) {
            nodeToDelete = p;
            break;
        }
        parent = p;
        if (p.left != null) {
            q.enqueue(p.left);
        }
        if (p.right != null) {
            q.enqueue(p.right);
        }
        p = (Node) q.dequeue();
    }

    if (nodeToDelete != null) {
        // Copy the data from the last node in the tree to the node to delete
        Node lastNode = p;
        Node lastNodeParent = parent;
        while (lastNode.right != null) {
            lastNodeParent = lastNode;
            lastNode = lastNode.right;
        }
        nodeToDelete.info = lastNode.info;

        // Delete the last node
        if (lastNodeParent == null) {
            root = null;
        } else if (lastNodeParent.left == lastNode) {
            lastNodeParent.left = null;
        } else {
            lastNodeParent.right = null;
        }
    }   

    //------------------------------------------------------------------------------------
     breadth(root,f);
     f.writeBytes("\r\n");
     f.close();
    }  

//=============================================================
  void f4() throws Exception
    {clear();
     loadData(10);
     String fname = "f4.txt";
     File g123 = new File(fname);
     if(g123.exists()) g123.delete();
     RandomAccessFile  f = new RandomAccessFile(fname, "rw"); 
     breadth(root,f);
     f.writeBytes("\r\n");
    //------------------------------------------------------------------------------------
     /*You must keep statements pre-given in this function.
       Your task is to insert statements here, just after this comment,
       to complete the question in the exam paper.*/

     // Perform breadth-first traversal
    Queue q = new Queue();
    Node parent = null;
    Node p = root;

    while (p != null) {
        fvisit(p, f);

        // Check if the current node has a left son and its price is less than 7
        if (p.left != null && p.left.info.price < 7) {
            // Perform a right rotation on this node
            p = rotateRight(p, parent);
        }

        parent = p;
        if (p.left != null) {
            q.enqueue(p.left);
        }
        if (p.right != null) {
            q.enqueue(p.right);
        }
        p = (Node) q.dequeue();
    }


    //------------------------------------------------------------------------------------
     breadth(root,f);
     f.writeBytes("\r\n");
     f.close();
    }
 
  // Right rotation function
    private Node rotateRight(Node node, Node parent) {
        Node newRoot = node.left;
        node.left = newRoot.right;
        newRoot.right = node;

        if (parent == null) {
            root = newRoot;
        } else if (parent.left == node) {
            parent.left = newRoot;
        } else {
            parent.right = newRoot;
        }

        return newRoot;
    }
    
    // Updated deleteByCopying method
    void deleteByCopying(int xPrice) throws Exception {
        clear();
        loadData(1);
        root = deleteByCopyingRec(root, xPrice);
        
        // Balance the tree after deletion
        root = balanceTree(root);
    
        // Write the updated tree to a text file
        String fname = "deleteByCopying_result.txt";
        File resultFile = new File(fname);
        if (resultFile.exists()) {
            resultFile.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        inOrder(root, f);
        f.close();
    }
    
    private Node deleteByCopyingRec(Node root, int xPrice) {
        if (root == null) {
            return root;
        }

        if (xPrice < root.info.price) {
            root.left = deleteByCopyingRec(root.left, xPrice);
        } else if (xPrice > root.info.price) {
            root.right = deleteByCopyingRec(root.right, xPrice);
        } else {
            // Node to delete is found

            // Case 1: Node with only one child or no child
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }

            // Case 2: Node with two children
            // Find the in-order successor (minimum in the right subtree)
            Node successor = findMin(root.right);

            // Copy the successor's data to this node
            root.info = successor.info;

            // Delete the successor
            root.right = deleteByCopyingRec(root.right, successor.info.price);
        }
        
        // Update height and balance factor and balance the tree
        root.height = 1 + Math.max(getHeight(root.left), getHeight(root.right));
        root.bal = getBalance(root);
    
        return root;
    }

    
    // Updated deleteByMerging method
    void deleteByMerging(int xPrice) throws Exception {
        clear();
        loadData(1);
        root = deleteByMergingRec(root, xPrice);

        // Balance the tree after deletion
        root = balanceTree(root);
    
        // Write the updated tree to a text file
        String fname = "deleteByMerging_result.txt";
        File resultFile = new File(fname);
        if (resultFile.exists()) {
            resultFile.delete();
        }
        RandomAccessFile f = new RandomAccessFile(fname, "rw");
        inOrder(root, f);
        f.close();
    }

    private Node deleteByMergingRec(Node root, int xPrice) {
        if (root == null) {
            return root;
        }

        if (xPrice < root.info.price) {
            root.left = deleteByMergingRec(root.left, xPrice);
        } else if (xPrice > root.info.price) {
            root.right = deleteByMergingRec(root.right, xPrice);
        } else {
            // Node to delete is found

            // Case 1: Node with only one child or no child
            if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            }

            // Case 2: Node with two children
            // Find the in-order predecessor (maximum in the left subtree)
            Node predecessor = findMax(root.left);

            // Copy the predecessor's data to this node
            root.info = predecessor.info;

            // Delete the predecessor
            root.left = deleteByMergingRec(root.left, predecessor.info.price);
        }
        
        // Update height and balance factor and balance the tree
        root.height = 1 + Math.max(getHeight(root.left), getHeight(root.right));
        root.bal = getBalance(root);

        return root;
    }

    private Node findMin(Node node) {
        while (node.left != null) {
            node = node.left;
        }
        return node;
    }

    private Node findMax(Node node) {
        while (node.right != null) {
            node = node.right;
        }
        return node;
    }

    // Add this method to the BSTree class
    Node search(int xPrice) {
        clear();
        loadData(1);
        return searchRec(root, xPrice);
    }

    // Helper method for searching recursively
    private Node searchRec(Node root, int xPrice) {
        if (root == null || root.info.price == xPrice) {
            return root;
        }

        if (xPrice < root.info.price) {
            return searchRec(root.left, xPrice);
        } else {
            return searchRec(root.right, xPrice);
        }
    }

 }
