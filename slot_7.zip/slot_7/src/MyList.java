/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author vuvan
 */
public class MyList {
    Node head, tail;

    MyList() {
        head = tail = null;
    }

    boolean isEmpty() {
        return (head == null);
    }

    void clear() {
        head = tail = null;
    }
    
    // (1) 
    void addLast(Student x) {
        Node q = new Node(x);
        if (isEmpty()) {
            head = tail = q;
            return;
        }
        tail.next = q;
        tail = q;
    }

    void visit(Node p) {
        if (p != null)
//            System.out.print(p.info);
            System.out.print(p.info + "\n");
    }

    void traverse() {
        Node p = head;
        while (p != null) {
            visit(p);
            p = p.next;
        }
        System.out.println("\n");
    }

    void addMany(String[] studentCodes, String[] fullNames, String[] dateOfBirths, String[] addresses, String[] classCodes) {
        int n = studentCodes.length;
        for (int i = 0; i < n; i++) {
            addLast(new Student(studentCodes[i], fullNames[i], dateOfBirths[i], addresses[i], classCodes[i]));
        }
    }

    // (2)
    Node searchByName(String xName) {
        Node p = head;
        while (p != null) {
            if (p.info.fullName.equals(xName))
                return p;
            p = p.next;
        }
        return null;
    }

    // (3)
    void addFirst(Student x) {
        Node q = new Node(x);
        q.next = head;
        head = q;
        if (tail == null) {
            tail = q;
        }
    }

       // (4)
    void insertAfter(Node q, Student x) {
        if (q == null)
            return;
        Node newNode = new Node(x, q.next);
        q.next = newNode;
        if (q == tail) {
            tail = newNode;
        }
    }

    // (5)
    void insertBefore(Node q, Student x) {
        if (q == null)
            return;
        if (q == head) {
            addFirst(x);
            return;
        }
        Node p = head;
        while (p != null && p.next != q) {
            p = p.next;
        }
        if (p != null) {
            insertAfter(p, x);
        }
    }

    // (6)
    void remove(Node q) {
        if (q == null)
            return;
        if (q == head) {
            head = head.next;
            if (head == null) {
                tail = null;
            }
            return;
        }
        Node p = head;
        while (p != null && p.next != q) {
            p = p.next;
        }
        if (p != null) {
            p.next = q.next;
            if (q == tail) {
                tail = p;
            }
        }
    }

    // (7)
    void remove(String xName) {
        Node p = head;
        Node prev = null;
        while (p != null) {
            if (p.info.fullName.equals(xName)) {
                if (p == head) {
                    head = head.next;
                    if (head == null) {
                        tail = null;
                    }
                } else {
                    prev.next = p.next;
                    if (p == tail) {
                        tail = prev;
                    }
                }
                return;
            }
            prev = p;
            p = p.next;
        }
    }
}
