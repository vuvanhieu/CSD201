class Student {
    String studentCode;
    String fullName;
    String dateOfBirth;
    String address;
    String classCode;

    Student() {}

    Student(String code, String name, String dob, String addr, String classCode) {
        studentCode = code;
        fullName = name;
        dateOfBirth = dob;
        address = addr;
        this.classCode = classCode;
    }

    public String toString() {
        return "(" + studentCode + ", " + fullName + ", " + dateOfBirth + ", " + address + ", " + classCode + ") ";
    }
}