class BSTree {
    Node root;

    BSTree() {
        root = null;
    }

    Node insertRec(Node root, int x) {
    //.........
    }
    // Insertion
    void insert(int x) {
    //.........
    }

    // In-order traversal
    void inOrder(Node p) {
    // ......
    }

    // Pre-order traversal
    void preOrder(Node p) {
    // .....
    }

    // Post-order traversal
    void postOrder(Node p) {
    // ......
    }
    
    Node searchRec(Node root, int x) {
    // ....
    
    return searchRec(root.right, x);
    }
    
    // Search for a node with key x
    Node search(int x) {
    // ....
    }

    int minValue(Node root) {
    // .....
    }
    
    Node deleteRec(Node root, int x) {
    // ....
    }
    
    // Delete a node by merging
    void deleteByMerging(int x) {
    // ....
    }
    
    Node deleteRecCopy(Node root, int x) {
    // ......
    }
    // Delete a node by copying
    void deleteByCopying(int x) {
    // ....
    }


    void visit(Node p) {
        System.out.print(p.info + " ");
    }
}