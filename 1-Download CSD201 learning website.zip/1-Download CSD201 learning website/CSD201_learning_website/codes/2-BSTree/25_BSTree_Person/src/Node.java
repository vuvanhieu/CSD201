public class Node {
   Person info;
   Node left,right;
   Node() {
   }
   Node(Person x) {
     info=x;
     left=right=null;
   }
}
